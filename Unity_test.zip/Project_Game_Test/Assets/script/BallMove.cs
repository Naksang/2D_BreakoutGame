﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallMove : MonoBehaviour
{
    public Rigidbody ballrigidbody;

    
    void Start()
    {
        ballrigidbody = GetComponent<Rigidbody>();

        ballrigidbody.AddForce(Vector3.up * 300.0f);
    }

    
}
