﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class MouseMove : MonoBehaviour
{
    Camera Camera;

    public GameObject mouse;

    void Start()
    {
        Camera = GameObject.Find("Main Camera").GetComponent<Camera>();
    }
        
    void Update()
    {
        if (!EventSystem.current.IsPointerOverGameObject())
        {
            Vector3 newPosition = Camera.main.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, 0));
            mouse.transform.position = new Vector3(newPosition.x, -4f);
        }
    }
}
